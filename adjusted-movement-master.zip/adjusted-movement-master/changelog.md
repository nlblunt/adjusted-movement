# CHANGELOG


## [0.1.2] 2020-06-22

### Features and Fixes
#### 0.1.2
- GM doesn't have to approve their own movement
- Option to disable request dialog, automatically send request to GM

### Initial Release
